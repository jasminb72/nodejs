Simple chat application written with socket.io.

Please change the IP address both in the chat.js and chat.html files - feel free to change the port number as well.

Start the chat server by executing "node chat.js" and open your browswer with the chat.html file to connect.

More info: http://tamaspiros.co.uk/2013/05/19/simple-chat-application-using-node-js-and-socket-io/
